# NODEMAILER ++

Technologies used for this project:
- NODEJS
- NODEMAILER

# 1. DOWNLOAD AND UNZIP
 Unzip the package
 Copy the package into your project's root 
# 2. DOWNLOAD DEPENDENCIES
```
cd nodemailer-main
npm install
```
# 3. USAGE
 import package
 const {enviarCorreo} = require('./nodemailer-main/main.js')
